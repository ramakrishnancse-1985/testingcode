package com.project.orchestratorengine.fileprocessor.aggregator;

import java.io.IOException;

import org.apache.camel.AggregationStrategy;
//import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;
//import org.apache.camel.processor.aggregate.AggregationStrategy;
//import org.apache.camel.processor.aggregate.AggregationStrategy;
//import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.slf4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * This is the aggregation strategy which is java code for <i>aggregating</i>
 * incoming messages with the existing aggregated message. In other words
 * you use this strategy to <i>merge</i> the messages together.
 */

//@Component
public class IcRequestAggregation implements AggregationStrategy {
	
	private static final Logger log = org.slf4j.LoggerFactory.getLogger(IcRequestAggregation.class);

    /**
     * Aggregates the messages.
     *
     * @param oldExchange  the existing aggregated message. Is <tt>null</tt> the
     *                     very first time as there are no existing message.
     * @param newExchange  the incoming message. This is never <tt>null</tt>.
     * @return the aggregated message.
     */
	
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
       
    	
    	String newBody = newExchange.getIn().getBody(String.class);
    	
        if (oldExchange == null) {        	
        	try {
        		newExchange.getIn().setBody(createMessageModel(newBody,newExchange));
			} catch (IOException e) {
				newExchange.setException(e);
			}
        	newBody = newExchange.getIn().getBody(String.class); 
        	return newExchange;
        }

        String oldBody = oldExchange.getIn().getBody(String.class);
        
    	try {
    		newExchange.getIn().setBody(updateMessageModel(newBody, oldBody));
		} catch (IOException e) {
			newExchange.setException(e);
		}
    	newBody = newExchange.getIn().getBody(String.class);
    	return newExchange;       
    }
    
	public String updateMessageModel(String newMessage, String oldMessage) throws IOException {
		Gson gson = new Gson();

		JsonObject newBody = gson.fromJson(newMessage, JsonObject.class);
		JsonObject newProductObject = new JsonObject();
		newProductObject = newBody.get("payload").getAsJsonObject().get("policy").getAsJsonObject().get("product").getAsJsonObject();
		
	//	JsonArray productJsonArray = new JsonArray();  
	//	productJsonArray.add(newBody.get("payload").getAsJsonObject().get("policy").getAsJsonObject().get("product").getAsJsonObject());
		
		JsonObject existingResponseJsonObject = gson.fromJson(oldMessage, JsonObject.class);
		existingResponseJsonObject.getAsJsonObject("payload").getAsJsonObject().get("policy").getAsJsonObject().getAsJsonArray("product").add(newProductObject);
		
		return gson.toJson(existingResponseJsonObject);
	}
	
	
	public String  createMessageModel(String message, Exchange newExchange) throws IOException {
		
		Gson gson = new Gson();
		
		JsonObject body = gson.fromJson(message, JsonObject.class);
		JsonObject responseJsonObject = new JsonObject();
		
		JsonArray productJsonArray = new JsonArray();  
		productJsonArray.add(body.get("payload").getAsJsonObject().get("policy").getAsJsonObject().get("product").getAsJsonObject());
		body.get("payload").getAsJsonObject().get("policy").getAsJsonObject().remove("product");
		body.get("payload").getAsJsonObject().get("policy").getAsJsonObject().add("product", productJsonArray);
		body.get("eventMetaData").getAsJsonObject().add("trackingId", gson.toJsonTree((String) newExchange.getProperty("eventId")));
		
	//	responseJsonObject.add("eventMetaData", body.get("eventMetaData").getAsJsonObject());
	//	responseJsonObject.get("eventMetaData").getAsJsonObject().add("trackingId", gson.toJsonTree((String) newExchange.getProperty("eventId")));
	//	responseJsonObject.add("payload",body.get("payload").getAsJsonObject());   
		
		return gson.toJson(body);
	}

    
}
