package com.project.orchestratorengine.demo.exception;

import org.apache.camel.CamelExchangeException;
import org.apache.camel.Exchange;
import org.slf4j.Logger;

public class ApplicationExceptionValidation {

	private static final Logger log = org.slf4j.LoggerFactory.getLogger(ApplicationExceptionValidation.class);

	public static boolean InterceptExceptionMessage(Exception exception) throws Exception {
		// isChildExchangeFailed(exception.g)
		if (exception instanceof CamelExchangeException) {
			CamelExchangeException cException = (CamelExchangeException) exception;
			if (isChildExchangeFailed(cException.getExchange())) {
				return true;
			}
		}
		log.info("inside dummyIntercept");
		return false;
		// return isChildExchangeFailed(exception.getExchange());

	}

	private static boolean isChildExchangeFailed(Exchange exchange) {

		if (exchange.getProperty("CamelCorrelationId") != null) {
			if (!exchange.getExchangeId().equalsIgnoreCase((String) exchange.getProperty("CamelCorrelationId"))) {
				// exchange.setProperty("ChildExchangeFailiure", "True");
				return true;
			}
		}
		return false;

	}
}