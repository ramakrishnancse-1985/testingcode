package com.project.orchestratorengine.demo.exception;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.ExtendedCamelContext;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.jsonvalidator.JsonValidationException;
import org.apache.camel.http.common.HttpOperationFailedException;
import org.apache.camel.model.LogDefinition;
import org.apache.camel.model.ProcessDefinition;
import org.apache.camel.model.ToDefinition;
import org.apache.camel.support.DefaultMessageHistory;
import org.apache.http.ProtocolException;
import org.json.JSONObject;
import org.slf4j.Logger;

import com.anthem.sbecbp.paymenthub.common.Constant;
import com.anthem.sbecbp.paymenthub.exception.EventLoggingException;
import com.anthem.sbecbp.paymenthub.util.JsonUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.networknt.schema.ValidationMessage;

public class ApplicationExceptions implements Processor {
	
	private static final Logger log = org.slf4j.LoggerFactory.getLogger(ApplicationExceptions.class);
	@Override
	public void process(Exchange exchange) throws Exception {
	//	Exception e = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
	//	String failure = "The message failed because " + e.getMessage(); 
		//exchange.getIn().setBody("FailureMessage - " + failure);
		log.info("Exception caught inside the ApplicationExceptions class");  
		String faiureMsg=prepareExceptionMessage(exchange);
		//String failureReqForService=prepareRequestForErrTransService(faiureMsg);
		String meaningfulMsg = faiureMsg;
		if (faiureMsg !=null && !faiureMsg.contains("errorTransformDroolsService")){
			meaningfulMsg=errorTranslator(exchange, faiureMsg);
		} 
		//exchange.getIn().setBody(prepareExceptionMessage(exchange));	
		exchange.getIn().setBody(meaningfulMsg);
		if (!isChildExchangeFailed(exchange)) { //not to throw exception to parent exchange if child exchange failed..
			exchange.setException(new Throwable("Failed"));
		}
		
	}
	
	private boolean isChildExchangeFailed(Exchange exchange) {
		
		if(exchange.getProperty("CamelCorrelationId") != null) {
			if (!exchange.getExchangeId().equalsIgnoreCase((String) exchange.getProperty("CamelCorrelationId"))) {
			//	exchange.setProperty("ChildExchangeFailiure", "True");
				return true;
			}
		}
		return false;
		
	}
	
	private String prepareExceptionMessage(Exchange exchange) {
		
		LinkedList messageHistory = (LinkedList) exchange.getProperties().get("CamelMessageHistory");
		DefaultMessageHistory actualNodehistory = (DefaultMessageHistory) messageHistory.get(messageHistory.size() - 2);
		DefaultMessageHistory currentNode = (DefaultMessageHistory) messageHistory.getLast();
		
		Exception exception = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
		
		Gson gson = new Gson();
		JsonObject failureMessage = new JsonObject();
		failureMessage.add("failureService",  gson.toJsonTree(Constant.MESSAGE_PRODCUT_PROCESSOR_SERVICE));
		failureMessage.add("failureRouteId", gson.toJsonTree(currentNode.getRouteId()));
		
		if (currentNode.getNode() instanceof LogDefinition || currentNode.getNode() instanceof  ProcessDefinition) {
			log.info("log definition.. need to handle it later");  
		} 
		
		else {
		ToDefinition nodeDefinition = (ToDefinition) currentNode.getNode();
		failureMessage.add("failureNode", gson.toJsonTree(nodeDefinition.getId()));
		failureMessage.add("failureUri", gson.toJsonTree(nodeDefinition.getUri().split(":")[0]));
		
		}
		
		String responsepayload = "";
		if (exception instanceof HttpOperationFailedException) {
			HttpOperationFailedException httpException = (HttpOperationFailedException) exception;
			responsepayload = httpException.getResponseBody();
			exchange.setProperty(Constant.RESPONSEPAYLOAD, responsepayload);

		} else if (exception instanceof ProtocolException) {
			responsepayload = Constant.PROTOCOLEXCEPTION;
			exchange.setProperty(Constant.RESPONSEPAYLOAD, responsepayload);
		} else if (exception instanceof JsonValidationException) {
			Set<ValidationMessage> hashSet= new LinkedHashSet(); 
			hashSet = ((JsonValidationException) exception).getErrors();
			JsonElement element = gson.toJsonTree(hashSet);
			JsonArray jsonArray = element.getAsJsonArray();
			responsepayload = gson.toJson(jsonArray);
			exchange.setProperty(Constant.RESPONSEPAYLOAD, responsepayload);
		} 
		else {
			responsepayload = exception.getMessage();
			//responsepayload = "Need more validation in exception class by developer to identify the response payload";
		}
		

		
		failureMessage.add("failiureResponseMsg", gson.toJsonTree(extractFailureMsg(responsepayload)));
		failureMessage.add("failureMessage", gson.toJsonTree(exception.getMessage()));
		return gson.toJson(failureMessage);
	}
	
	private String extractFailureMsg(String responsepayload) {
		String msg=responsepayload;
		if(JsonUtil.isJson(responsepayload)) {
			Gson gson=new Gson();
			JsonArray obj=gson.fromJson(responsepayload, JsonArray.class);
			msg=obj.get(0).getAsJsonObject().get("message").getAsString();
		}
		return msg;
	}
	
	
	private String errorTranslator(Exchange exchange, String message) {
		JSONObject jsonrequest;
		CamelContext context = exchange.getContext();
	//	ModelCamelContext camelContext = context.adapt(ModelCamelContext.class);
		ExtendedCamelContext camelContextExtended = context.adapt(ExtendedCamelContext.class);

		ProducerTemplate producerTemplate = context.createProducerTemplate();
		camelContextExtended.setEventNotificationApplicable(false);
		String errortranslatorresponse =null;
		try {		
		errortranslatorresponse = (String) producerTemplate.sendBodyAndProperty("direct:ErrortranslatorExtService",
				ExchangePattern.InOut, message, Exchange.NOTIFY_EVENT, Boolean.TRUE);
		camelContextExtended.setEventNotificationApplicable(true);
		}catch(Exception e) {
			exchange.setException(new EventLoggingException(e));
		} 	
		exchange.setProperty(Constant.RESPONSEPAYLOAD, errortranslatorresponse);
		return errortranslatorresponse;

	}


}
