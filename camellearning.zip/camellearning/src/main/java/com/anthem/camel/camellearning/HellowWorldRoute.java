package com.anthem.camel.camellearning;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.dataformat.csv.CsvDataFormat;

public class HellowWorldRoute extends RouteBuilder {
	
	@Override
	public void configure() throws Exception{
		System.out.println("Hellow World");
		
        CsvDataFormat csvDataFormat = new CsvDataFormat();
        csvDataFormat.setHeaderDisabled(true);
        csvDataFormat.setDelimiter('|');
		
		
		 from("file:///apps/sclc/inputfile?noop=false").
           unmarshal().
           csv().
           marshal(csvDataFormat)
         .to("jolt:/joltSpec/sfdcToJson.json?inputType=JsonString&amp;outputType=JsonString").to("file:///apps/sclc/output_box");
		 
//		from("file:input_box?noop=true").
//		 .to("file:///apps/sclc/output_box");
		
		
	}

}
