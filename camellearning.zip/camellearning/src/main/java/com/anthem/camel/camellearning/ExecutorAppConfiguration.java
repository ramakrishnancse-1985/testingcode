package com.anthem.camel.camellearning;

import javax.sql.DataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class ExecutorAppConfiguration {
	
	@Bean("callidusDataSource")
	@ConfigurationProperties(prefix="spring.callidus")  
	public DataSource secondaryDataSource() {
		System.out.println("callidusDataSource is initiating");
	    return DataSourceBuilder.create().build();
	}
	
	
	@Bean("ascsDataSource")
	@ConfigurationProperties(prefix="spring.ascs")  
	public DataSource secondaryDataSourceAscs() {
		System.out.println("ascsDataSource is initiating");
	    return DataSourceBuilder.create().build();
	}
	
	@Bean("escsDataSource")
	@ConfigurationProperties(prefix="spring.escs")  
	public DataSource secondaryDataSourceEscs() {
	    return DataSourceBuilder.create().build();
	}
	
	@Bean("dataSource")
	@Primary
	@ConfigurationProperties(prefix="spring.datasource")  
	public DataSource primaryDataSource() {
	    return DataSourceBuilder.create().build();
	}

}
