package com.anthem.camel.camellearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@ImportResource({"firststep2.xml"})
@EnableEurekaServer
//@ContextConfiguration(locations = {"firststep.xml"})
@ComponentScan("com.anthem.camel.camellearning")
public class CamellearningApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(CamellearningApplication.class, args);



//	      ApplicationContext appContext = new ClassPathXmlApplicationContext(
//	    	         "firststep.xml");
//	    	      CamelContext camelContext = SpringCamelContext.springCamelContext(appContext, false);
//	    	      try {
//	    	         camelContext.start();
//	    	      } finally {
//	    	         camelContext.stop();
//	    	      }
	    	   
		
		
//		SpringApplication.run(CamellearningApplication.class, args);
//		
//		CamelContext camelContext = new DefaultCamelContext();
//		//camelContext.addRoutes(new HellowWorldRoute());
//		
//		while(true){
//		camelContext.start();
		}
		
	}	
		



