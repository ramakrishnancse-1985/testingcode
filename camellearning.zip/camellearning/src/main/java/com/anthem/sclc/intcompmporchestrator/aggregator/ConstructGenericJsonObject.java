package com.anthem.sclc.intcompmporchestrator.aggregator;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.slf4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class ConstructGenericJsonObject {
	
	private static final Logger log = org.slf4j.LoggerFactory.getLogger(ConstructGenericJsonObject.class);
	
	public void constructJsonMessage(Exchange exchange) throws Exception {
		String originalPayload = (String) exchange.getProperty("bodyBkp");    
		String isNoRecordAllowed = (String) exchange.getIn().getHeader("isNoRecordAllowed");    
	    log.info(" isNoRecordAllowed value:"+ isNoRecordAllowed); 
		
		Gson gson = new Gson();
		JsonObject originalJson = gson.fromJson(originalPayload, JsonObject.class);
	
		String newBody;
		JsonObject newBodyJson = null;
		JsonObject finalConstructedJson = new JsonObject();
		finalConstructedJson.add("inboundPayload", originalJson);
		log.info("Output from SQL: " + exchange.getIn().getBody().toString());
		
		if (exchange.getIn().getBody() instanceof String) {
			newBody = exchange.getIn().getBody(String.class);
			newBodyJson = gson.fromJson(newBody, JsonObject.class);		 	
			finalConstructedJson.add("responsePayload", newBodyJson); 
		} 
		else {
			List<Map<String,Object>> body = (List<Map<String, Object>>) exchange.getIn().getBody();
		//for some cases no record condition is ok	
			if ( body.isEmpty() ){
				throw new Exception("No record found"); 				
			}
			 
			if (body.size() > 1) {
				throw new Exception("More than one record found"); 
			}
			finalConstructedJson.add("responsePayload", gson.toJsonTree(body));
		}
		
		log.info("newly constructured generic message: " + gson.toJson(finalConstructedJson));  
		exchange.getOut().setHeader("responsePayload", "no data is avaialble");
		exchange.getOut().setBody(gson.toJson(finalConstructedJson)); 
		
	}
	
   
	
	public void constructJsonMessageNoRecord(Exchange exchange) throws Exception {
		String originalPayload = (String) exchange.getProperty("bodyBkp");    
	
		Gson gson = new Gson();
		JsonObject originalJson = gson.fromJson(originalPayload, JsonObject.class);
	
		String newBody;
		JsonObject newBodyJson = null;
		JsonObject finalConstructedJson = new JsonObject();
		finalConstructedJson.add("inboundPayload", originalJson);
		log.info("Output from SQL: " + exchange.getIn().getBody().toString());
		
		if (exchange.getIn().getBody() instanceof String) {
			newBody = exchange.getIn().getBody(String.class);
			newBodyJson = gson.fromJson(newBody, JsonObject.class);		 	
			finalConstructedJson.add("responsePayload", newBodyJson); 
		} 
		else {
			List<Map<String,Object>> body = (List<Map<String, Object>>) exchange.getIn().getBody();
		//for some cases no record condition is ok	
			if ( body.isEmpty() ){
			exchange.getOut().setHeader("dataFromDB", "no data is available");
			exchange.getOut().setBody(gson.toJson(finalConstructedJson)); 
			return;
			}
			 
			if (body.size() > 1) {
				throw new Exception("More than one record found"); 
			}
			finalConstructedJson.add("responsePayload", gson.toJsonTree(body));
		}
		
		log.info("newly constructured generic message: " + gson.toJson(finalConstructedJson)); 
		exchange.getOut().setBody(gson.toJson(finalConstructedJson)); 
		
	}
	
	public void constructDerivedMapping(Exchange exchange) throws Exception {

		Gson gson = new Gson();

		String newBody;
		JsonObject newBodyJson = null;
		if (exchange.getIn().getBody() instanceof String) {

			newBody = exchange.getIn().getBody(String.class);
			newBodyJson = gson.fromJson(newBody, JsonObject.class);

			JsonObject payloadObj = newBodyJson.getAsJsonObject("payload").getAsJsonObject();
			JsonObject policyObj = payloadObj.get("policy").getAsJsonObject();
			JsonObject prodcutObj = policyObj.get("product").getAsJsonObject();
			JsonObject premiumObj = prodcutObj.get("premium").getAsJsonObject();

			// derivededDiscountFactor
			if (!prodcutObj.get("fundingType").isJsonNull() & !prodcutObj.get("fundingType").toString().isEmpty()) {
				if (prodcutObj.get("fundingType").getAsString().equals("ASO")) {
					prodcutObj.get("agent").getAsJsonObject().add("derivededDiscountFactor",
							policyObj.get("policyExpansion3"));
				} else if (prodcutObj.get("fundingType").getAsString().equals("FI")) {
					prodcutObj.get("agent").getAsJsonObject().add("derivededDiscountFactor",
							policyObj.get("policyExpansion4"));
				} else {
					prodcutObj.get("agent").getAsJsonObject().addProperty("derivededDiscountFactor", "100");
				}
			}
			// premium amount set 0 if its empty
			
			if (!premiumObj.get("premiumAmount").isJsonNull()) {
				log.info("premiumAmount: " + premiumObj.get("premiumAmount").toString());
				if (premiumObj.get("premiumAmount") != null
						&& premiumObj.get("premiumAmount").toString().equalsIgnoreCase("\"\"")) {
					premiumObj.getAsJsonObject().addProperty("premiumAmount", "0");

				}

			}

			// derivedRenewalType
			if (!prodcutObj.get("productRenewalType").isJsonNull()) {
				if (prodcutObj.get("productRenewalType").getAsString().equalsIgnoreCase("New")) {
					prodcutObj.addProperty("derivedRenewalType", "N");
				}
				if (prodcutObj.get("productRenewalType").getAsString().equalsIgnoreCase("Renew")) {
					prodcutObj.addProperty("derivedRenewalType", "R");
				}
				if (prodcutObj.get("productRenewalType").getAsString().equalsIgnoreCase("Renew With Growth")) {
					prodcutObj.addProperty("derivedRenewalType", "R");
				}
				if (prodcutObj.get("productRenewalType").getAsString().equalsIgnoreCase("IGAP Sold")) {
					prodcutObj.addProperty("derivedRenewalType", "I");
				}

			}

			log.info("newly constructured : " + gson.toJson(newBodyJson));
			exchange.getIn().setBody(gson.toJson(newBodyJson));
		}
	}

	
	public void constructAgentData(Exchange exchange) throws Exception {
		String originalPayload = (String) exchange.getProperty("bodyBkp");    
	
		Gson gson = new Gson();
		JsonObject originalJson = gson.fromJson(originalPayload, JsonObject.class);
	
		String newBody;
		JsonObject newBodyJson = null;
		JsonObject finalConstructedJson = new JsonObject();
		finalConstructedJson.add("inboundPayload", originalJson);
		 String stringbody = exchange.getIn().getBody(String.class);
		log.info("Output from agent Info Service : " + stringbody);
		
		if (stringbody instanceof String) {
			newBodyJson = gson.fromJson(stringbody, JsonObject.class);		 	
			finalConstructedJson.add("responsePayload", newBodyJson); 
		} 
		else {
			List<Map<String,Object>> body = (List<Map<String, Object>>) exchange.getIn().getBody();
		//for some cases no record condition is ok	
			if ( body.isEmpty() ){
			exchange.getOut().setHeader("dataFromDB", "no data is available");
			exchange.getOut().setBody(gson.toJson(finalConstructedJson)); 
			return;
			}
			 
			if (body.size() > 1) {
				throw new Exception("More than one record found"); 
			}
			finalConstructedJson.add("responsePayload", gson.toJsonTree(body));
		}
		
		log.info("newly constructured generic message: " + gson.toJson(finalConstructedJson)); 
		exchange.getOut().setBody(gson.toJson(finalConstructedJson)); 
		
	}
	
	

}
