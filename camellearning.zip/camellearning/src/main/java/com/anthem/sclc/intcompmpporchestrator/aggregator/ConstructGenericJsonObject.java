package com.anthem.sclc.intcompmpporchestrator.aggregator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class ConstructGenericJsonObject  {
	
	private static final Logger log = org.slf4j.LoggerFactory.getLogger(ConstructGenericJsonObject.class);

	public void constructJsonMessage(Exchange exchange) throws Exception {
		String originalPayload = (String) exchange.getProperty("bodyBkp");    
		
		Gson gson = new Gson();
		JsonObject originalJson = gson.fromJson(originalPayload, JsonObject.class);
	
		String newBody;
		JsonObject newBodyJson = null;
		JsonObject finalConstructedJson = new JsonObject();
		finalConstructedJson.add("inboundPayload", originalJson);
		
		if (exchange.getIn().getBody() instanceof String) {
			newBody = exchange.getIn().getBody(String.class);
			newBodyJson = gson.fromJson(newBody, JsonObject.class);		 	
			finalConstructedJson.add("responsePayload", newBodyJson); 
		} else {
			List<Map<String,Object>> body = (List<Map<String, Object>>) exchange.getIn().getBody();
			
			if (body.isEmpty()) {
				throw new Exception("No record found"); 
			}
			 
			if (body.size() > 1) {
				throw new Exception("More than one record found"); 
			}
			finalConstructedJson.add("responsePayload", gson.toJsonTree(body));
		}
		
		log.info("newly constructured generic message: " + gson.toJson(finalConstructedJson));   
		exchange.getOut().setBody(gson.toJson(finalConstructedJson)); 
		
	}
	public void constructDerivedMapping(Exchange exchange) throws Exception {

		Gson gson = new Gson();

		String newBody;
		JsonObject newBodyJson = null;
		if (exchange.getIn().getBody() instanceof String) {

			newBody = exchange.getIn().getBody(String.class);
			newBodyJson = gson.fromJson(newBody, JsonObject.class);

			JsonObject payloadObj = newBodyJson.getAsJsonObject("payload").getAsJsonObject();
			JsonObject policyObj = payloadObj.get("policy").getAsJsonObject();
			JsonObject prodcutObj = policyObj.get("product").getAsJsonObject();
			JsonObject premiumObj = prodcutObj.get("premium").getAsJsonObject();

			// derivededDiscountFactor
			if (!prodcutObj.get("fundingType").isJsonNull() & !prodcutObj.get("fundingType").toString().isEmpty()) {
				if (prodcutObj.get("fundingType").getAsString().equals("ASO")) {
					prodcutObj.get("agent").getAsJsonObject().add("derivededDiscountFactor",
							policyObj.get("policyExpansion3"));
				} else if (prodcutObj.get("fundingType").getAsString().equals("FI")) {
					prodcutObj.get("agent").getAsJsonObject().add("derivededDiscountFactor",
							policyObj.get("policyExpansion4"));
				} else {
					prodcutObj.get("agent").getAsJsonObject().addProperty("derivededDiscountFactor", "100");
				}
			}
			// premium amount set 0 if its empty
			if (!premiumObj.get("premiumAmount").isJsonNull()) {
				log.info("premiumAmount: " + premiumObj.get("premiumAmount").toString());
				if (premiumObj.get("premiumAmount") != null
						&& premiumObj.get("premiumAmount").toString().equalsIgnoreCase("\"\"")) {
					premiumObj.getAsJsonObject().addProperty("premiumAmount", "0");

				}

			}

			// derivedRenewalType
			if (!prodcutObj.get("productRenewalType").isJsonNull()) {
				if (prodcutObj.get("productRenewalType").getAsString().equalsIgnoreCase("New")) {
					prodcutObj.addProperty("derivedRenewalType", "N");
				}
				if (prodcutObj.get("productRenewalType").getAsString().equalsIgnoreCase("Renew")) {
					prodcutObj.addProperty("derivedRenewalType", "R");
				}
				if (prodcutObj.get("productRenewalType").getAsString().equalsIgnoreCase("Renew With Growth")) {
					prodcutObj.addProperty("derivedRenewalType", "R");
				}
				if (prodcutObj.get("productRenewalType").getAsString().equalsIgnoreCase("IGAP Sold")) {
					prodcutObj.addProperty("derivedRenewalType", "I");
				}

			}

			log.info("newly constructured : " + gson.toJson(newBodyJson));
			exchange.getIn().setBody(gson.toJson(newBodyJson));
		}
	}
	
    public void constructJsonMessageNoRecord(Exchange exchange) throws Exception {
        String originalPayload = (String) exchange.getProperty("bodyBkp");    
  
        Gson gson = new Gson();
        JsonObject originalJson = gson.fromJson(originalPayload, JsonObject.class);
  
        String newBody;
        JsonObject newBodyJson = null;
        JsonObject finalConstructedJson = new JsonObject();
        finalConstructedJson.add("inboundPayload", originalJson);
        log.info("Output from SQL: " + exchange.getIn().getBody().toString());
        
        if (exchange.getIn().getBody() instanceof String) {
              newBody = exchange.getIn().getBody(String.class);
              newBodyJson = gson.fromJson(newBody, JsonObject.class);                 
              finalConstructedJson.add("responsePayload", newBodyJson); 
        } 
        else {
              List<Map<String,Object>> body = (List<Map<String, Object>>) exchange.getIn().getBody();
        //for some cases no record condition is ok      
              if ( body.isEmpty() ){
            	  log.info("body is empty");
             exchange.getOut().setHeader("dataFromDB", "no data is available");
             exchange.getOut().setBody(gson.toJson(finalConstructedJson));
             log.info("body when no data found from SQL: " + exchange.getIn().getBody().toString());
              return;
              }
              
              if (body.size() > 1) {
                    throw new Exception("More than one record found"); 
              }
              finalConstructedJson.add("responsePayload", gson.toJsonTree(body));
        }
        
        log.info("newly constructured generic message: " + gson.toJson(finalConstructedJson)); 
        exchange.getOut().setBody(gson.toJson(finalConstructedJson)); 
        
  }
    
	public void constructAgentData(Exchange exchange) throws Exception {
		String originalPayload = (String) exchange.getProperty("bodyBkp");    
	
		Gson gson = new Gson();
		JsonObject originalJson = gson.fromJson(originalPayload, JsonObject.class);
	
		String newBody;
		JsonObject newBodyJson = null;
		JsonObject finalConstructedJson = new JsonObject();
		finalConstructedJson.add("inboundPayload", originalJson);
		//handle exceptions properly
		//try to get agent Title and L&C info in this method.
		String stringbody = exchange.getIn().getBody(String.class);
		log.info("Output from agent Info Service : " + stringbody);
		
		if (stringbody instanceof String) {
			newBodyJson = gson.fromJson(stringbody, JsonObject.class);		 	
			finalConstructedJson.add("responsePayload", newBodyJson); 
		} 
		else {

				throw new Exception("Getting ASCS data Issue"); 
		
		}
		
		log.info("newly constructured generic message: " + gson.toJson(finalConstructedJson)); 
		exchange.getOut().setBody(gson.toJson(finalConstructedJson)); 
		
	}  
	
public void constructJsonWithUpdateMemCnt(Exchange exchange) throws Exception {
		
		Gson gson = new Gson();
	
		String newBody;
		JsonObject newBodyJson = null;
		
		if (exchange.getIn().getBody() instanceof String) {
			newBody = exchange.getIn().getBody(String.class);
			newBodyJson = gson.fromJson(newBody, JsonObject.class);	
			
			JsonObject payloadObj = newBodyJson.getAsJsonObject("payload").getAsJsonObject();
			JsonObject policyObj = payloadObj.get("policy").getAsJsonObject();
			JsonObject prodcutObj = policyObj.get("product").getAsJsonObject();
			JsonObject memberObj=prodcutObj.get("member").getAsJsonObject();
			
			log.info("Updating Member count with derivedRenewalType : " +prodcutObj.get("derivedRenewalType").toString());   
			
			if (!prodcutObj.get("derivedRenewalType").isJsonNull() & !prodcutObj.get("derivedRenewalType").toString().isEmpty()) {
				log.info("if derivedRenewalType :" +prodcutObj.get("derivedRenewalType").toString());
				if (prodcutObj.get("derivedRenewalType").getAsString().equals("N")) {
					memberObj.add("memberCount", memberObj.get("memberExpansion2"));
				} else if (prodcutObj.get("derivedRenewalType").getAsString().equals("R")) {
					if(memberObj.get("memberExpansion2").getAsInt() >=  memberObj.get("memberCount").getAsInt()){
						int memberCount = memberObj.get("memberExpansion2").getAsInt()-memberObj.get("memberCount").getAsInt();
						log.info("if memberExpansion2 > memberCount " +memberCount);
						memberObj.addProperty("memberCount", memberCount);
					}else {
						int memberCount = memberObj.get("memberCount").getAsInt()-memberObj.get("memberExpansion2").getAsInt();
						log.info("if memberCount > memberExpansion2 " +memberCount);
						memberObj.addProperty("memberCount", memberCount);
					} 
			}

		}
		log.info("newly constructured generic message: " + gson.toJson(newBodyJson));   
		exchange.getOut().setBody(gson.toJson(newBodyJson)); 
		}
		
	}	
	
public void constructJsonWithGencProduct(Exchange exchange) throws Exception {
		
		Gson gson = new Gson();
	
		String newBody;
		JsonObject newBodyJson = null;
		
		if (exchange.getIn().getBody() instanceof String) {
			newBody = exchange.getIn().getBody(String.class);
			newBodyJson = gson.fromJson(newBody, JsonObject.class);	
			
			JsonObject payloadObj = newBodyJson.getAsJsonObject("payload").getAsJsonObject();
			JsonObject policyObj = payloadObj.get("policy").getAsJsonObject();
			JsonObject prodcutObj = policyObj.get("product").getAsJsonObject();
			
			log.info("Updating derived product  with derived genc product ");   
			if (prodcutObj.has("derivedGencProduct")){
			if (!prodcutObj.get("derivedGencProduct").isJsonNull() & !prodcutObj.get("derivedGencProduct").toString().isEmpty()) {
				prodcutObj.add("derivedProduct", prodcutObj.get("derivedGencProduct"));
					} 
			}else {
				log.info("not an gencproduct");
			}
		}
		log.info("newly constructured generic message: " + gson.toJson(newBodyJson));   
		exchange.getOut().setBody(gson.toJson(newBodyJson)); 
		}

public void getAgentTitleInfo(Exchange exchange) throws Exception {
	
	String agentInfo="ANA DIRECTOR OF SALES - AM,ANA MANAGER ACCOUNT SERVICES I,ANA MANAGER ACCOUNT SERVICES II,ANA REGIONAL VP - AM" ; 
	 String[] agent = agentInfo.split(",");
		List<String> agentList = new ArrayList<String>(Arrays.asList(agent));
		 log.info("Fetches Employee agent "+agent);  		
		
	Gson gson = new Gson();

	String newBody;
	JsonObject newBodyJson = null;
	if (exchange.getIn().getBody() instanceof String) {

		newBody = exchange.getIn().getBody(String.class);
		newBodyJson = gson.fromJson(newBody, JsonObject.class);

		JsonObject payloadObj = newBodyJson.getAsJsonObject("payload").getAsJsonObject();
		JsonObject policyObj = payloadObj.get("policy").getAsJsonObject();
		JsonObject prodcutObj = policyObj.get("product").getAsJsonObject();
		JsonObject agentObj = policyObj.get("agent").getAsJsonObject();

		// check for agent title
		if (!agentObj.get("IntJobTitle").isJsonNull() & !prodcutObj.get("IntJobTitle").toString().isEmpty()) {
			log.info("Fetches Employee inside IF "+agentObj.get("IntJobTitle").getAsString()); 
			 if (agentList.contains(agentObj.get("IntJobTitle").getAsString())) {
				 agentObj.addProperty("agentExpansion5", "Y");
	 		}else {
	 			agentObj.addProperty("agentExpansion5", "N");
	 		}
			
		}


		log.info("newly constructured : " + gson.toJson(newBodyJson));
		exchange.getIn().setBody(gson.toJson(newBodyJson));
	}
}

}
