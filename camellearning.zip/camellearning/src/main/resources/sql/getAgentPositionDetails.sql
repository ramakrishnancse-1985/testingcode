SELECT DISTINCT
CS_POSITION.NAME as positionName
FROM CS_POSITION@TC_LINK
WHERE
CS_POSITION.REMOVEDATE =
TO_DATE('1/1/2200','MM/DD/YYYY') 
and CS_POSITION.GENERICATTRIBUTE2 =:#${exchangeProperty.callidusAgentCode} 
and to_date(:#${exchangeProperty.sfdcLobCategoryEffDate}, 'MM/DD/YYYY') >=CS_POSITION.EFFECTIVESTARTDATE --lobCategoryEffDate
and to_date(:#${exchangeProperty.sfdcLobCategoryEffDate}, 'MM/DD/YYYY') <=CS_POSITION.EFFECTIVEENDDATE --lobCategoryEffDate
