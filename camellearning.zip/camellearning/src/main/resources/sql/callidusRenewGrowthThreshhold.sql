/* Formatted on 11/12/2020 9:55:16 PM (QP5 v5.300) */
SELECT distinct gc.GenericNumber1    AS threshold
  FROM cs_categorytree@TC_LINK          tree,
       cs_category_classifiers@TC_LINK  cat_cls,
       cs_classifier@TC_LINK            cls,
       cs_genericclassifier@TC_LINK     gc
 WHERE     tree.categorytreeseq = cat_cls.categorytreeseq
       AND cat_cls.classifierseq = cls.classifierseq
       AND cls.classifierseq = gc.classifierseq
       AND tree.effectivestartdate < cls.effectiveenddate
       AND tree.effectiveenddate > cls.effectivestartdate
       AND cat_cls.effectivestartdate < cls.effectiveenddate
       AND cat_cls.effectiveenddate > cls.effectivestartdate
       AND cls.effectivestartdate = gc.effectivestartdate
       AND cls.effectiveenddate = gc.effectiveenddate
       AND tree.name = 'National_Growth_Sale_Action_Threshold'
       AND cls.islast = 1
       AND cls.removedate = '01/Jan/2200'
       AND gc.islast = 1
       AND gc.removedate = '01/Jan/2200'
       AND gc.genericattribute1 = :#${exchangeProperty.derivedProductName} 
       AND gc.genericattribute2 = :#${exchangeProperty.fundingType}       
       AND to_date(:#${exchangeProperty.sfdcLobCategoryEffDate}, 'MM/DD/YYYY') >=gc.GenericDate1 --lobCategoryEffDate
       AND to_date(:#${exchangeProperty.sfdcLobCategoryEffDate}, 'MM/DD/YYYY') <=gc.GenericDate2 --lobCategoryEffDate
  --   AND gc.genericattribute2 = 'Medicare - Group Medicare Advantage (LPPO)' -- SALESFORCE_PRODUCT_NAME
  --   AND gc.genericattribute3 = 'N'       --RECORDTYPENAME ( Renew-R, New-N)   
  --   and '01/Jan/2200' <=gc.GenericDate2 --lobCategoryEffDate  
  --   and '01/Jan/2200' >=gc.GenericDate1 --lobCategoryEffDate