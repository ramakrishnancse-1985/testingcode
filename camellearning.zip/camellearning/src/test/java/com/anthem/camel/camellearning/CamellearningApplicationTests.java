package com.anthem.camel.camellearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamellearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
